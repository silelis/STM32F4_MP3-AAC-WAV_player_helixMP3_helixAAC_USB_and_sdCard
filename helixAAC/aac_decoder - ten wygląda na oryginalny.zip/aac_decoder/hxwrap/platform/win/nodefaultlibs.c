#if defined(WIN32) && defined(_MSC_VER)
  #pragma comment(linker, "-nodefaultlib:libircmt.lib")
#endif
